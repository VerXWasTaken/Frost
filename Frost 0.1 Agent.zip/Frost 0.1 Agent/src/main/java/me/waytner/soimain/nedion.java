package me.waytner.soimain;



public class nedion {

    public static boolean xray = true;
    public void keypress(int k) {
        isXrayBlock();
    }
    public boolean isXrayBlock() {
        if (this.xray) {
            return true;
        }
        return false;
    }
    public boolean as() {
        if (nedion.xray == true) {
            return true;
        }
        return false;
    }
    public float sa() {
        if (nedion.xray) {
            return 4.5f;
        }
        return 3f;
    }
}
