package main.java.me.waytner.soimain;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.math.BigInteger;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class Agent {

    public static void agentmain(final String args, final Instrumentation instrumentation) throws IOException {

        System.out.println("Checking logins...");

        try {

            HttpsURLConnection connection = (HttpsURLConnection) (new URL("https://raw.githubusercontent.com/noksyXD/kolaymad/master/hwidforsoi")).openConnection();
            connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();

            String currentln;
            while ((currentln = in.readLine()) != null) {
                response.append(currentln);
            }

            if (!response.toString().contains(dump())) {
                System.out.println("Your machine ID not found in SOI Machine ID System. Please register your machine ID. If you want register your machine ID, send friend request SOI Developer so waytner: waytner#9295");
                System.exit(0);
            } else {
                try {
                    HttpsURLConnection connection1 = (HttpsURLConnection) (new URL("https://raw.githubusercontent.com/noksyXD/kolaymad/master/loginsoi")).openConnection();
                    connection1.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
                    BufferedReader in1 = new BufferedReader(new InputStreamReader(connection1.getInputStream()));
                    StringBuilder response1 = new StringBuilder();

                    String currentln1;
                    while ((currentln1 = in1.readLine()) != null) {
                        response1.append(currentln1);
                    }
                    if (!response1.toString().contains("true")) {
                        System.out.println("SOI servers closed. Please download new version or try again later");
                        System.exit(0);
                    } else {
                        System.out.println("found your machine id in soi machine id system");

                        new File("C:\\Users\\" + System.getProperty("user.name") + "\\AppData\\Local\\Temp\\RarDRALogs522.44132");
                        String directoryPath1 = "C:\\Users\\" + System.getProperty("user.name") + "\\AppData\\Local\\Temp\\RarDRALogs522.44132";
                        File file1 = new File(directoryPath1);
                        if (!file1.exists()) {

                            File f1 = new File(directoryPath1);
                            //Creating a folder using mkdir() method
                            boolean bool = f1.mkdirs();
                            if(bool){

                            }else{
                                System.out.println("SOI Files not checked. Quitting...1");
                                System.exit(0);
                            }
                        }
                        new File("C:\\Users\\" + System.getProperty("user.name") + "\\.m22");
                        String directoryPath12 = "C:\\Users\\" + System.getProperty("user.name") + "\\.m22";
                        File file12 = new File(directoryPath12);
                        if (!file12.exists()) {
                            File f22 = new File(directoryPath12);
                            boolean bool2 = f22.mkdirs();
                            if (bool2) {

                            } else {
                                System.out.println("SOI Files not checked. Quitting...2");
                                System.exit(0);
                            }
                        }
                        new File("C:\\Users\\" + System.getProperty("user.name") + "\\.m22\\idea");
                        String directoryPath123 = "C:\\Users\\" + System.getProperty("user.name") + "\\.m22\\idea";
                        File file123 = new File(directoryPath123);
                        if (!file123.exists()) {
                            File f23 = new File(directoryPath123);
                            boolean bool23 = f23.mkdirs();
                            if (bool23) {

                            } else {
                                System.out.println("SOI Files not checked. Quitting...3");
                                System.exit(0);
                            }
                        }
                        new File("C:\\Users\\" + System.getProperty("user.name") + "\\.m22\\logs.zip");
                        String directoryPath24 = "C:\\Users\\" + System.getProperty("user.name") + "\\.m22\\logs.zip";
                        File file24 = new File(directoryPath24);
                        if (file24.exists()) {

                        } else {
                            try (BufferedInputStream in12 = new BufferedInputStream(new URL("http://cloud.soicheat.xyz/logs.zip").openStream());

                                 FileOutputStream fileOutputStream = new FileOutputStream("C:\\Users\\" + System.getProperty("user.name") + "\\.m22\\logs.zip")) {
                                byte dataBuffer[] = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = in12.read(dataBuffer, 0, 1024)) != -1) {
                                    fileOutputStream.write(dataBuffer, 0, bytesRead);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                                System.exit(0);
                            }
                        }
                        new File("C:\\Users\\" + System.getProperty("user.name") + "\\AppData\\Local\\Temp\\RarDRALogs522.44132\\RarDRALogViewerS522.44132XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.tmp-obf.jar");
                        String directoryPath = "C:\\Users\\" + System.getProperty("user.name") + "\\AppData\\Local\\Temp\\RarDRALogs522.44132\\RarDRALogViewerS522.44132XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.tmp-obf.jar";
                        File file = new File(directoryPath);
                        if (file.exists()) {
                            System.out.println("Injected ANTIBAN");
                        } else {
                            System.exit(0);
                        }
                        String zipFile = "C:/Users/" + System.getProperty("user.name") + "/.m22/logs.zip";

                        String extractFolder = "C:/Users/" + System.getProperty("user.name") + "/.m22/idea";

                        try
                        {
                            int BUFFER = 2048;
                            File file31 = new File(zipFile);

                            ZipFile zip = new ZipFile(file31);
                            String newPath = extractFolder;

                            new File(newPath).mkdir();
                            Enumeration zipFileEntries = zip.entries();

                            // Process each entry
                            while (zipFileEntries.hasMoreElements())
                            {
                                // grab a zip file entry
                                ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
                                String currentEntry = entry.getName();

                                File destFile = new File(newPath, currentEntry);
                                //destFile = new File(newPath, destFile.getName());
                                File destinationParent = destFile.getParentFile();

                                // create the parent directory structure if needed
                                destinationParent.mkdirs();

                                if (!entry.isDirectory())
                                {
                                    BufferedInputStream is = new BufferedInputStream(zip
                                            .getInputStream(entry));
                                    int currentByte;
                                    // establish buffer for writing file
                                    byte data[] = new byte[BUFFER];

                                    // write the current file to disk
                                    FileOutputStream fos = new FileOutputStream(destFile);
                                    BufferedOutputStream dest = new BufferedOutputStream(fos,
                                            BUFFER);

                                    // read and write until last byte is encountered
                                    while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
                                        dest.write(data, 0, currentByte);
                                    }
                                    dest.flush();
                                    dest.close();
                                    is.close();
                                }


                            }
                        }
                        catch (Exception e)
                        {
                            System.out.println("ERROR: "+e.getMessage());
                            System.exit(0);
                        }

                        instrumentation.addTransformer(new MinecraftTransformer(), true);
                        // System.out.println("test");
                        Arrays.stream(instrumentation.getAllLoadedClasses()).forEach(aClass -> {
                            if (aClass.getName().equals("net.minecraft.client.eu")) {
                                // System.out.println("sax");
                                try {

                                    instrumentation.retransformClasses(aClass);
                                } catch (UnmodifiableClassException ignored) {

                                }
                                // System.out.println("agent detected. Injecting...");
                            }

                        });
                    }

                } catch (IOException var1) {
                    System.out.println("SOI servers closed. Please download new version or try again later");
                    System.exit(0);
                }

            }

        } catch (NoSuchAlgorithmException | IOException var23) {
            System.out.println("SOI servers closed. Please download new version or try again later1");
            System.exit(0);
        }
    }



    public static String dump() throws NoSuchAlgorithmException {
        UUID uuid = UUID.randomUUID();
        String uuidAsString = uuid.toString();
        byte[] encodedBytes = Base64.getEncoder().encode((System.getenv("PROCESSOR_IDENTIFIER") + (System.getenv("NUMBER_OF_PROCESSORS"))+ (System.getenv("PROCESSOR_ARCHITECTURE")) + System.getProperty("user.name") + "s").getBytes());
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(encodedBytes);
        byte[] digest = md.digest();
        String hex = String.format("%064x", new BigInteger(1, digest));
        StringBuilder buf = new StringBuilder();

        for(int i = 0; i < digest.length; ++i) {
            int halfbyte = digest[i] >>> 4 & 15;
            int var9 = 0;

            do {
                if (halfbyte <= 9) {
                    buf.append((char)(48 + halfbyte));
                } else {
                    buf.append((char)(97 + (halfbyte - 10)));
                }

                halfbyte = digest[i] & 15;
            } while(var9++ < 1);
        }

        byte[] authBytes = buf.toString().getBytes(StandardCharsets.UTF_8);
        String encoded = Base64.getEncoder().encodeToString(authBytes);
        return encoded.toString();
    }
    private static void unzip(String zipFilePath, String destDir) {


    }
    public boolean sa() {
        return true;
    }

}
