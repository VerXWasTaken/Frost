package me.waytner.soimain;

public class justexample {
    public static void wtf() {
        System.out.println("just try");
    }
}
