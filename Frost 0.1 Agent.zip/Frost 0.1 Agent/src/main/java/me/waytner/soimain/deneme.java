package me.waytner.soimain;


public class deneme {


    public boolean xray = true;

    public static void main(String[] args) {
        int k = 1 * 123;

    }
    public Object shouldanan() {
        if (xray) {
            return this;
        }
        return false;
    }
}
