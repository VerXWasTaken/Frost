package main.java.me.waytner.soimain;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.scene.control.Tab;


public class anan31 {

    private static ArrayList<Tab> tabs;
    private static int currentTab;


    private static int currentRenderMod;
    private static int currentMovementMod;

    public anan31() {
        tabs = new ArrayList();
        currentTab = 0;

        currentRenderMod = 0;
        currentMovementMod = 0;






    }

    public static ArrayList<Tab> getTabs() {
        return tabs;
    }

    public static int getCurrentMovementMod() {
        return currentMovementMod;
    }
    public static int getCurrentRenderMod() {
        return currentRenderMod;
    }
    public static int getCurrentTab() {
        return currentTab;
    }
    public static void keyPress(int k) {
        return;
    }

    private static void toggleMod(String n){

    }

}

