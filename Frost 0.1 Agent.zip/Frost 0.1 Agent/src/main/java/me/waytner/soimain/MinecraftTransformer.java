package me.waytner.soimain;




import squadutilities.*;
import squadutilities.tree.*;
import squadutilities.Opcodes;
import me.waytner.soimain.Injector;
import java.util.List;


public class MinecraftTransformer extends Injector {


    public void inject(final ClassReader classReader, final ClassNode classNode) {


        if (classNode.name.equals("net/minecraft/client/bx")) {
            //   System.out.println("discord group find");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("()F")) {
                    final InsnList insn = new InsnList();
                    Label l0 = new Label();
                    insn.add(new LabelNode(l0));
                    insn.add(new FieldInsnNode(Opcodes.GETSTATIC, "Reach", "state", "Z"));
                  //  insn.add(new InsnNode(Opcodes.IFEQ));

                    insn.add(new LdcInsnNode(new Float("6.1")));
                    insn.add(new InsnNode(Opcodes.FRETURN));
                    methodNode.instructions.insert(insn);
                    //   System.out.println("return ekledim");
                }
            }
        }
        if (classNode.name.equals("net/minecraft/client/bx")) {
            //   System.out.println("discord group find");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("g") && methodNode.desc.equals("()Z")) {
                    final InsnList insn = new InsnList();
                    Label l0 = new Label();
                    insn.add(new LabelNode(l0));
                    insn.add(new FieldInsnNode(Opcodes.GETSTATIC, "Reach", "state", "Z"));
                    insn.add(new InsnNode(Opcodes.ICONST_1));
                    Label l2 = new Label();
                    insn.add(new LabelNode(l2));

                    //  insn.add(new JumpInsnNode(Opcodes.IFEQ, l1));
                    insn.add(new InsnNode(Opcodes.ICONST_1));
                    insn.add(new InsnNode(Opcodes.IRETURN));
                    methodNode.instructions.insert(insn);
                    //   System.out.println("return ekledim");
                }
            }
        }

        if (classNode.name.equals("sonoyuncu/net/arikia/dev/drpc/DiscordGroup")) {
         //   System.out.println("discord group find");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("g") && methodNode.desc.equals("()Ljava/io/File;")) {
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                 //   System.out.println("return ekledim");
                }
            }
        }
        if (classNode.name.equals("sonoyuncu/net/arikia/dev/drpc/DiscordGroup")) {
          //  System.out.println("discord group find");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("()I")) {
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                  //  System.out.println("return ekledim");
                }
            }
        }
        if (classNode.name.equals("net/minecraft/client/hD")) {
            //System.out.println("abooooo!!");
            //System.out.println("net minecraft client iw found");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("X") && methodNode.desc.equals("()V")) {
                    AbstractInsnNode target = null;
                    for (final AbstractInsnNode abs : methodNode.instructions.toArray()) {
                        if (abs.getOpcode() == 184) {
                            target = abs;
                            break;
                        }
                    }
                    final InsnList insn = new InsnList();
                    insn.add(new MethodInsnNode(184, "SOI", "onMotionUpdate", "()V", false));
                    methodNode.instructions.insert(target, insn);
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");
                    System.out.println("ekledim abeler");

                  //  System.out.println("jso31 onmotionupdate added");
                }
            }
        }
        if (classNode.name.equals("rC")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("run") && methodNode.desc.equals("()V")) {
                  //  System.out.println("sabo");

                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("rC")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("c") && methodNode.desc.equals("()V")) {
                 //   System.out.println("sabo x2");

                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("net/minecraft/client/er")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("g") && methodNode.desc.equals("()V")) {
                    //   System.out.println("sabo x2");

                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("rC")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("b") && methodNode.desc.equals("()V") && methodNode.access == ACC_PRIVATE) {
                 //   System.out.println("sabo x3");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("rC")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("b") && methodNode.desc.equals("()V")) {
                  //  System.out.println("sabo x4");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("rC")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("(Ljava/lang/Runnable;Z)V")) {
                 //   System.out.println("sabo x5");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(RETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("rC")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("(Ljava/lang/String;)Ljava/lang/String;")) {
                  //  System.out.println("sabo x6");
                    final InsnList insn = new InsnList();

                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(ARETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("aX")) {
            //System.out.println("abooooo!!");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("c") && methodNode.desc.equals("()Ljava/lang/String;")) {
                  //  System.out.println("fi da c java lan string buldum la");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(ARETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("aX")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("(Ljava/lang/String;)Ljava/lang/String;")) {
                  //  System.out.println("fi da a java lan string x2 buldum la");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(ARETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("aX")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("b") && methodNode.desc.equals("()Ljava/lang/String;")) {
                 //   System.out.println("fi da b java lan string buldum la");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(ARETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("aX")) {
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("()Ljava/lang/String;")) {
                  //  System.out.println("fi da a java lan string buldum la");
                    final InsnList insn = new InsnList();
                    insn.add(new LdcInsnNode(" "));
                    insn.add(new InsnNode(ARETURN));
                    methodNode.instructions.insert(insn);
                }
            }
        }
        if (classNode.name.equals("SOI")) {
           // System.out.println("abooooo!!");
            //System.out.println("[Flixy] Passed. #1");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("instance") && methodNode.desc.equals("()Lnet/minecraft/client/cN;")) {
                    AbstractInsnNode target = null;
                    for (final AbstractInsnNode abs4 : methodNode.instructions.toArray()) {
                        if (abs4.getOpcode() == 1) {
                            target = abs4.getNext();
                            break;
                        }
                    }
                    methodNode.instructions.remove(target.getPrevious());
                    final InsnList insn = new InsnList();
                    insn.add(new MethodInsnNode(184, "net/minecraft/client/cN", "a", "()Lnet/minecraft/client/cN;", false));
                    methodNode.instructions.insertBefore(target, insn);
                  //  System.out.println("jso31 finded and du injected");
                }
            }
        }




        if (classNode.name.equals("net/minecraft/client/fu")) {
            //System.out.println("net minecraft client cv found");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("a") && methodNode.desc.equals("(F)V")) {
                    //System.out.println("qweqxx");
                    AbstractInsnNode target = null;
                    for (final AbstractInsnNode abs4 : methodNode.instructions.toArray()) {
                        if (abs4 instanceof FieldInsnNode && ((FieldInsnNode)abs4).name.equals("o") && ((FieldInsnNode)abs4).owner.equals("net/minecraft/client/fu")) {
                            //System.out.println("qweqxxx");
                            target = abs4.getNext().getNext().getNext();
                            break;
                        }
                    }
                    final InsnList insnList2 = new InsnList();
                    insnList2.add(new VarInsnNode(21, 5));
                    insnList2.add(new VarInsnNode(21, 6));
                    insnList2.add(new MethodInsnNode(184, "SOI", "onRender2D", "(II)V", false));
                    methodNode.instructions.insert(target, insnList2);
                  //  System.out.println("jso31 onrender2d added");
                }
            }
        }


        if (classNode.name.equals("net/minecraft/client/cN")) {
            //System.out.println("abooooo!!");
            //System.out.println("net minecraft client in found");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("b") && methodNode.desc.equals("()V")) {
                   // System.out.println("net minecraft client in c mehtod found");
                    AbstractInsnNode target = null;
                    int count = 0;
                    for (final AbstractInsnNode abs : methodNode.instructions.toArray()) {
                        if (abs instanceof MethodInsnNode && ((MethodInsnNode)abs).name.equals("getEventKeyState") && ++count == 2) {
                            //System.out.println("modulemanager listenkeyaddedxx");
                            target = abs.getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext();
                        }
                    }
                    final InsnList insnList3 = new InsnList();
                    insnList3.add(new VarInsnNode(21, 2));
                    insnList3.add(new MethodInsnNode(184, "ModuleManager", "listenKey", "(I)V", false));
                  //  insnList3.add(new VarInsnNode(21, 2));
                  //  insnList3.add(new MethodInsnNode(184, "TabManager", "keyPress", "(I)V", false));


                    methodNode.instructions.insert(target, insnList3);
                  //  System.out.println("modulemanager listenkeyadded");
                }
            }
        }
        if (classNode.name.equals("net/minecraft/client/cN")) {
            //System.out.println("abooooo!!");
            //System.out.println("net minecraft client in found");
            for (final MethodNode methodNode : classNode.methods) {
                if (methodNode.name.equals("b") && methodNode.desc.equals("()V")) {
                    // System.out.println("net minecraft client in c mehtod found");
                    AbstractInsnNode target = null;
                    int count = 0;
                    for (final AbstractInsnNode abs : methodNode.instructions.toArray()) {
                        if (abs instanceof MethodInsnNode && ((MethodInsnNode)abs).name.equals("getEventKeyState") && ++count == 2) {
                            //System.out.println("modulemanager listenkeyaddedxx");
                            target = abs.getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext().getNext();
                        }
                    }
                    final InsnList insnList3 = new InsnList();
                    insnList3.add(new VarInsnNode(21, 2));
                    insnList3.add(new MethodInsnNode(184, "TabManager", "keyPress", "(I)V", false));
                    //  insnList3.add(new VarInsnNode(21, 2));
                    //  insnList3.add(new MethodInsnNode(184, "TabManager", "keyPress", "(I)V", false));


                    methodNode.instructions.insert(target, insnList3);
                    //  System.out.println("modulemanager listenkeyadded");
                }
            }
        }



    }
}
