import org.lwjgl.input.Keyboard;

public class Hud extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public Hud() {
		super("Hud", Keyboard.KEY_NUMPAD2, Category.MOVEMENT);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
