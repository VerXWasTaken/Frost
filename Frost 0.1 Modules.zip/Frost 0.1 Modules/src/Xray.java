
import java.util.ArrayList;

import org.lwjgl.input.Keyboard;


public class Xray extends Module {
	
	
	
	public static boolean state = false;
	public static boolean statechat = false;
	
	public Xray() {
		super("Xray", Keyboard.KEY_X, Category.RENDER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }


	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
