
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class ModuleManager {
   public static List<Module> modules = new ArrayList<Module>();
   public static TabManager tabManager;
   

   public ModuleManager() {
	   
	//   cmdManager = new CommandManager();
	   tabManager = new TabManager();
	   modules.add(new AntiBan());
	   modules.add(new LegitKillAura());
	   modules.add(new NoKnockback());
	   modules.add(new ChestStealer());
	   modules.add(new InvisibleCleaner());
	   modules.add(new FastPlace());
	   modules.add(new SpeedMine());
	   modules.add(new AutoArmor());
	   modules.add(new VanillaFly());
	   modules.add(new FastHit());
	  modules.add(new Scaffold());
		modules.add(new Aimbot());
		modules.add(new Reach());
	//	modules.add(new Xray());
		modules.add(new NoFall());
		modules.add(new Speed());
		
		modules.add(new Aura());
		modules.add(new Help());
		modules.add(new Step());
		modules.add(new Fly());
		modules.add(new Hud());
	
//	modules.add(new Deneme());
	
	
//	modules.add(new Scaffold());
	
//	modules.add(new Xray());
//	modules.add(new Glide());
//	modules.add(new ESP());
	
	
	
	
//	modules.add(new Nuker());
	
//	modules.add(new FastBow());
   }
   public static void listenKey(int key)  {
	   
	   for (Module mod : ModuleManager.getModules()) {
		   if (mod.getModuleKey() == key) {
			   mod.toggle();
		   }
	   }
   }
   
   public static Module getModule(String moduleName) {
      if (moduleName != null) {
         Iterator<Module> var2 = getModules().iterator();

         while(var2.hasNext()) {
            Module mod = (Module)var2.next();
      	   //System.out.println("XXX : " + mod);
            if (mod.moduleName.toString().contains(moduleName)) {
            	//System.out.println("Dogru");
               return mod;
            }
         }
      }
      //System.out.println("???");
      return null;
   }

   public static Module getModule(Class<?> clazz) {
      if (clazz != null) {
         Iterator<?> var2 = getModules().iterator();

         while(var2.hasNext()) {
            Module mod = (Module)var2.next();
            if (mod.getClass() == clazz) {
               return mod;
            }
         }
      }

      return null;
   }
   
   
   public static List<Module> getModules() {
      return modules;
   }
   
}
