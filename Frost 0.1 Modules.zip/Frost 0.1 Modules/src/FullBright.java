
import org.lwjgl.input.Keyboard;

public class FullBright extends Module {

	public static boolean state = true;
	public static boolean statechat = false;
	public FullBright() {
		super("FullBright", Keyboard.KEY_NONE, Category.RENDER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
		}
}