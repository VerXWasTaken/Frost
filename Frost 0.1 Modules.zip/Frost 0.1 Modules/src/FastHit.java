import org.lwjgl.input.Keyboard;


public class FastHit extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	public FastHit() {
		super("FastHit", Keyboard.KEY_NONE, Category.COMBAT);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
		}
}