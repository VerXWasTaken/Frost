
import org.lwjgl.input.Keyboard;

public class ChestStealer extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	public ChestStealer() {
		super("ChestStealer", Keyboard.KEY_V, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
		}
}
