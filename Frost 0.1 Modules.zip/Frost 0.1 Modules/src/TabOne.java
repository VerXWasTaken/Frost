
public class TabOne extends Tab {

	
	
}
