
import org.lwjgl.input.Keyboard;

public class Help extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public Help() {
		super("Help", Keyboard.KEY_NUMPAD1, Category.MOVEMENT);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
