
public class Module {
	
   public String moduleName;
   public int moduleKey;
   public boolean moduleState;
   public Category category;
   
   public Module(String moduleName, int moduleKey, Category c) {
      this.moduleName = moduleName;
      this.moduleKey = moduleKey;
      this.category = c;
      this.moduleState = false;
   }
   public enum Category {
	   COMBAT("Combat"),
	   MOVEMENT("Movement"),
	   PLAYER("Player"),
	   RENDER("Render");
	   public String name;
	   Category(String name) {
		   this.name = name;
	   }
   }
   
   private boolean isEnabled;
   //public void onBruh() {}
   public Module getModByName(String name) {
	    for (Module mod : ModuleManager.getModules()) {
	        if ((mod.moduleName.trim().equalsIgnoreCase(name.trim()))
	                || (mod.toString().trim().equalsIgnoreCase(name.trim()))) {
	            return mod;
	        }
	    }

	    return null;
	}
   public boolean isEnabled() {
	   return this.isEnabled;
   }
   public Module getInstance() {
       for (final Module mod : ModuleManager.getModules()) {
           if (mod.getClass().equals(this.getClass())) {
               return mod;
           }
       }
       return null;
   }
   public int getModuleKey() {
      return moduleKey;
   }
   
   public void setModuleKey(int newModuleKey) {
      moduleKey = newModuleKey;
   }

   public boolean getModuleState() {
      return this.moduleState;
   }

   public void setModuleState(boolean moduleState) {
      if (moduleState) {
         this.moduleState = true;
      } 
      else {
         this.moduleState = false;
      }

   }
public void onEnable() {
	}
public void onDisable() {
	}
   public void onToggled() {
		if (this.moduleState) {
			try {
				onEnable();
			} catch (Exception e) {
				
			}
		} else {
			try {
				onDisable();
			} catch (Exception e) {
			}
   }
		}
   
   public String getModuleName() {
	   return moduleName;
   }
   
   public void toggle() {
	 //  instance().ah.a(new net.minecraft.qW(moduleName + (this.getModuleState() ? "enabled" : "disabled")));
      this.setModuleState(!this.getModuleState());
      this.onToggled();
      //Printer.print(moduleName + (this.getModuleState() ? " toggle on." : " toggle off."));
   }
}
