
import org.lwjgl.input.Keyboard;


public class InvisibleCleaner extends Module {

	public static boolean state = true;
	public static boolean statechat = false;
	public InvisibleCleaner() {
		super("InvisibleCleaner", Keyboard.KEY_NONE, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
		}
}
