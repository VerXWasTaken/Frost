
import org.lwjgl.input.Keyboard;

public class FastPlace extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public FastPlace() {
		super("FastPlace", Keyboard.KEY_Z, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
