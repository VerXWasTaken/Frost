
import java.awt.Color;





import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;

import javax.net.ssl.HttpsURLConnection;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;

import net.minecraft.BlockPos;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;

public class SOI {
    
	public static boolean statenofall = false;
	public static boolean statenofall1 = false;
	public static boolean statekillaura = false;
	public static boolean statekillaura1 = false;
	public static boolean statelegitkillaura = false;
	public static boolean statelegitkillaura1 = false;
	public static boolean statespeed = false;
	public static boolean statespeed1 = false;
	public static boolean stateaimbot = false;
	public static boolean statenaimbot1 = false;
	
	public static boolean statestep = false;
	public static boolean statestep1 = false;
//	public net.minecraft.sW blockState;
	public static boolean statenoknockback = false;
	public static boolean statenoknockback1 = false;
	public static boolean stateautoarmor = false;
	public static boolean stateautoarmor1 = false;
	public static boolean statecheststealer = false;
	public static boolean statecheststealer1 = false;
	public static boolean statespeedmine = false;
	public static boolean statespeedmine1 = false;
	public static boolean statehelp = false;
	public static boolean statehelp1 = false;
	public static boolean statefly = false;
	public static boolean statefly1 = false;
	public static boolean statenofallmodule = false;
	public static boolean statereach = false;
	public static boolean statereach1 = false;
	public static boolean statefasthit = false;
	public static boolean statefasthit1 = false;
	public static boolean stateinvisiblecleaner = false;
	public static boolean stateinvisiblecleaner1 = false;
	public static boolean statefastplace = false;
	public static boolean statefastplace1 = false;

	
	
	private final static List blocks = new ArrayList();
	private final static Set<net.minecraft.g9> entityList = Sets.<net.minecraft.g9>newHashSet();
//	public static net.minecraft.bZ b;
//	private net.minecraft.d8 defaultBlockState;
	
	protected go anan;
	private static net.minecraft.nR timer111;
	public void onUpdate() {
		
	}
	
	
	
	
	
	
	private static Random random = new Random();
	public static long a = 5003l;
	
	   public static float yawx, pitchx;
	public static ModuleManager moduleManager;
   public static boolean lol = false;
   static double counter = 0;
   public static boolean anan12 = true;
   
   public static int count = 0;
   public static int currentTab123;
   public static net.minecraft.client.kR instance() {
	   return null;
   }
   public static int code1;
	public static int EventKey1(int code1) {
		return code1 = code1;
	}
   
   
   
   

private static Random rand = new Random();

public static float[] smoothFacePos(net.minecraft.ma vec, net.minecraft.kC entity) {
	double diffX = vec.b + 0.5 - instance().f.E;
	double diffY = vec.a + 0.5
			- (instance().f.a + getEyeHeight(entity));
	double diffZ = vec.c + 0.5 - instance().f.e;
	double dist = sqrt_double(diffX * diffX + diffZ * diffZ);
	float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;

	float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);

	boolean aim = false;
	float max = 5;
	if ((wrapAngleTo180_float(yaw -instance().f.X)) > max * 2) {
		aim = true;
	} else if ((wrapAngleTo180_float(yaw - instance().f.X)) < -max * 2) {
		aim = true;
	}
	if ((wrapAngleTo180_float(pitch - instance().f.t)) > max * 4) {
		aim = true;
	} else if ((wrapAngleTo180_float(pitch - instance().f.t)) < -max
			* 4) {
		aim = true;
	}
	float lastYaw = yaw;
	float lastPitch = pitch;
	// Minecraft.getMinecraft().thePlayer.rotationYaw += yawChange;
	// Minecraft.getMinecraft().thePlayer.rotationPitch += pitchChange;
	if (aim) {
		
		lastYaw += (
				wrapAngleTo180_float(yaw - instance().f.X))
				/ (2.5 * (rand.nextDouble() * 2 + 1));
		lastPitch += (
				wrapAngleTo180_float(pitch - instance().f.t))
				/ (2.5 * (rand.nextDouble() * 2 + 1));
	}
    float f = 0.6F * 0.6F + 0.2F;
    float gcd = f * f * f * 1.2F;
lastYaw -= yaw % gcd;
    lastPitch -= pitch % gcd;
    return new float[] {lastYaw, lastPitch};

}

public static double noluo() {
	return 3.6;
}

public static float sqrt_double(double value) {
	return (float) Math.sqrt(value);
}
public static float wrapAngleTo180_float(float value) {
	value = value % 360.0F;

	if (value >= 180.0F) {
		value -= 360.0F;
	}

	if (value < -180.0F) {
		value += 360.0F;
	}

	return value;
}
   public static Timer timer = new Timer();
   public static synchronized float[] getRotationsToEnt(net.minecraft.oN entity) {
		final double var4 = entity.E - instance().f.E;
		final double var6 = entity.e - instance().f.e;
		final double var8 = (double)(entity.a + getEyeHeight(entity) / 1.3 - (instance().f.a + getEyeHeight(entity)));
		final double var14 = (float)Math.sqrt(var4 * var4 + var6 * var6);
	    final float rotationYaw = (float) (Math.atan2(var6, var4) * 180.0D / Math.PI) - 90.0F;
	    final float rotationPitch = (float)(-(Math.atan2(var8, var14) * 180.0 / Math.PI));
    return new float[]{rotationYaw, -rotationPitch};
	}
	public static synchronized void faceEntity(net.minecraft.oN entity) {
		final double var4 = entity.E - instance().f.E;
		final double var6 = entity.e - instance().f.e;
		final double var8 = (double)(entity.a + getEyeHeight(entity) / 1.3 - (instance().f.a + getEyeHeight(entity)));
		final double var14 = (float)Math.sqrt(var4 * var4 + var6 * var6);
	   instance().f.X = (float) (Math.atan2(var6, var4) * 180.0D / Math.PI) - 90.0F;
	   instance().f.t = (float)(-(Math.atan2(var8, var14) * 180.0 / Math.PI));
    }
	
	private static float getEyeHeight(net.minecraft.oN entityPlayer) {
        float f = 1.62f;
		if (instance().f.cz != null && instance().f.cz.d) {
			f -= 0.08f;
		}
		return f;
	}
	private static float getEyeHeight() {
        float f = 1.62f;
		if (instance().f.cz != null && instance().f.cz.d) {
			f -= 0.08f;
		}
		return f;
	}
	
	
   public static float getDistanceToEntity(net.minecraft.client.hD entityMe, net.minecraft.oN entityIn) {
	      float f = (float)(entityMe.E - entityIn.E);
	      float f1 = (float)(entityMe.a - entityIn.a);
	      float f2 = (float)(entityMe.e - entityIn.e);
	      return (float)Math.sqrt((double)(f * f + f1 * f1 + f2 * f2));
	   }
   
   public static float getDistanceToEntity(net.minecraft.client.hD entityMe, net.minecraft.ok entityIn) {
	      float f = (float)(entityMe.E - entityIn.E);
	      float f1 = (float)(entityMe.a - entityIn.a);
	      float f2 = (float)(entityMe.e - entityIn.e);
	      return (float)Math.sqrt((double)(f * f + f1 * f1 + f2 * f2));
	   }
//   public static float getDistanceToEntity1(net.minecraft.nU entityIn) {
//	      float f = (float)(entityIn.m - entityIn.m);
//	      float f1 = (float)(entityIn.X - entityIn.X);
//	      float f2 = (float)(entityIn.n - entityIn.n);
//	      return (float)Math.sqrt((double)(f * f + f1 * f1 + f2 * f2));
//	   }
 //  public static net.minecraft.tG getCenter(final net.minecraft.uo bb) {
 //      return new net.minecraft.tG(bb.f + (bb.c - bb.f) * 0.5, bb.a + (bb.d - bb.a) * 0.5, bb.e + (bb.b - bb.e) * 0.5);
 //  }

   public static void drawGradientSideways(int left, int top, int right, int bottom, int col1, int col2) {
      float f = (float)(col1 >> 24 & 255) / 255.0F;
      float f1 = (float)(col1 >> 16 & 255) / 255.0F;
      float f2 = (float)(col1 >> 8 & 255) / 255.0F;
      float f3 = (float)(col1 & 255) / 255.0F;
      float f4 = (float)(col2 >> 24 & 255) / 255.0F;
      float f5 = (float)(col2 >> 16 & 255) / 255.0F;
      float f6 = (float)(col2 >> 8 & 255) / 255.0F;
      float f7 = (float)(col2 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(f1, f2, f3, f);
      GL11.glVertex2d((double)left, (double)top);
      GL11.glVertex2d((double)left, (double)bottom);
      GL11.glColor4f(f5, f6, f7, f4);
      GL11.glVertex2d((double)right, (double)bottom);
      GL11.glVertex2d((double)right, (double)top);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

  // instance().G.capabilities.isFlying = true;
 //  public static void drawBorderedRect(int left, int top, int right, int bottom, int borderWidth, int insideColor, int borderColor, boolean borderIncludedInBounds) {
 //     net.minecraft.client.b_.a(left - (!borderIncludedInBounds ? borderWidth : 0), top - (!borderIncludedInBounds ? borderWidth : 0), right + (!borderIncludedInBounds ? borderWidth : 0), bottom + (!borderIncludedInBounds ? borderWidth : 0), borderColor);
 //     net.minecraft.client.b_.a(left + (borderIncludedInBounds ? borderWidth : 0), top + (borderIncludedInBounds ? borderWidth : 0), right - (borderIncludedInBounds ? borderWidth : 0), bottom - (borderIncludedInBounds ? borderWidth : 0), insideColor);
 //  }
   public static String random(final int length, final char[] chars) {
       final StringBuilder stringBuilder = new StringBuilder();
       for(int i = 0; i < length; i++)
           stringBuilder.append(chars[new Random().nextInt(chars.length)]);
       return stringBuilder.toString();
   }
   public static void removeEntity(net.minecraft.g9 entityIn)
   {
	   
   }
   public static String random(final int length, final String chars) {
       return random(length, chars.toCharArray());
   }

   public static String randomString(final int length) {
       return random(length, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
   }
   public static float nextFloat(final float startInclusive, final float endInclusive) {
       if(startInclusive == endInclusive || endInclusive - startInclusive <= 0F)
           return startInclusive;

       return (float) (startInclusive + ((endInclusive - startInclusive) * Math.random()));
   }
   public static MSTimer timerspam = new MSTimer();
   public static long delayspam = randomDelay(3000, 3800);
   public static int aac3glideDelay;
   
   public static float getSpeed() {
       return (float) Math.sqrt(instance().f.Z * instance().f.Z + instance().f.q * instance().f.q);
   }
   public static void strafe(final float speed) {

       final double yaw = getDirection();
       instance().f.Z = -Math.sin(yaw) * speed;
       instance().f.q = Math.cos(yaw) * speed;
   }
   public static double getDirection() {
       float rotationYaw = instance().f.X;

       if(instance().f.bh < 0F)
           rotationYaw += 180F;

       float forward = 1F;
       if(instance().f.bh < 0F)
           forward = -0.5F;
       else if(instance().f.bh > 0F)
           forward = 0.5F;

       if(instance().f.aW > 0F)
           rotationYaw -= 90F * forward;

       if(instance().f.aW < 0F)
           rotationYaw += 90F * forward;

       return Math.toRadians(rotationYaw);
   }
 //  public static boolean isSelected(final net.minecraft.nU entity) {
 //      if(entity instanceof net.minecraft.nb && entity != instance().aw) {
 //              if(entity instanceof net.minecraft.o6) {
 //                  return true;
 //              }
 //          }
 //      return false;
 //  }
   public static String getStringModified(String str) {
       str.replaceAll("ğr", "");

       return str;
   }
   public static void what() {

	   //TODO: onUpdate
	   if(Speed.state) {
	   }
   }
   
//   public static void start() {
//	   final net.minecraft.qI u0131temStack = new net.minecraft.qI(net.minecraft.dL.b((int)1));
//	   final net.minecraft.hk tagCompound = new net.minecraft.hk();
 //       int n = 0;
//        while (lIlIlIIIllIIllIl(n, 30000)) {
//            tagCompound.a(String.valueOf(n), Double.NaN);
//            ++n;
//        }
//        qI.a(tagCompound);
//        int n2 = 0;
//        while (lIlIlIIIllIIllIl(n2, 40)) {
//        	
//        	++n2;
//        }
//    }
//	private static boolean lIlIlIIIllIIllIl(int n, int n2) {
//	    return n < n2;
//	}
	//private void setBlockAndFacing (net.minecraft.BlockPos var1) {
	//	instance()..a(var1.a(0, -1, 0))
	//}
	protected double minX;
    protected double minY;
    protected double minZ;
    protected double maxX;
    protected double maxY;
    protected double maxZ;
    private static double motionX;
	private static double motionZ;
    private int getItem(final int id) {
		
		for (int index = 9; index < 45; ++index) {
			final net.minecraft.d8 item = instance().f.cj.a(index).a();
			if (item != null && net.minecraft.qQ.a(item.a()) == id) {
				return index;
			}
		}
		return -1;
	}
	private static int getProt(net.minecraft.d8 stack) {
		if ((stack != null) && ((stack.a() instanceof net.minecraft.qc))) {
			int normalValue = ((net.minecraft.qc) stack.a()).n;
			int enchantmentValue = net.minecraft.az.a(net.minecraft.iq.e.v, stack);
			return normalValue + enchantmentValue;
		}
		return -1;
	}
	private int[] bestArmor;
	static int delay;
	private static int[] boots;
	private static int[] chestplate;
	private static int[] helmet;
	private static int[] leggings;
	private static int xPos;
	private static int yPos;
	private static int zPos;
	
	private static int radius = 4;
//	private net.minecraft.BlockPos blockpos;
//	private net.minecraft.l0 enumfacing;
	private boolean rotated = false;
//	net.minecraft.client.lb world1 = instance().g;
//	protected static net.minecraft.client.gr player() {
//		return instance().aw;
//	}
//	protected static net.minecraft.client.cz playerController() {
//		return instance().O;
//	}
//	protected static void sendPacket(net.minecraft.km p) {
//		player().cI.a(p);
//	}
//	protected static net.minecraft.client.lb world() {
//		return instance().g;
//	}
//	public static net.minecraft.bA getHeldItem()
 //   {
//		net.minecraft.client.gr _p = player();
 //       return _p.b7.a();
 //   }
	static int second = 2;
	
//	Timer timerxxx = new Timer();
	
	
	static TimeHelper timer313 = new TimeHelper();
	public static net.minecraft.client.hD player() {
		return instance().f;
	}
	
	
	
	static TimeHelper bos = new TimeHelper();
	
	
	/*
	 * else if(pb.a(1, -1, 1) != null) {
			if(pb.a(0, -1, 1) != null)
				place(pb.a(0, -1, 1), net.minecraft.v1.NORTH);
			place(pb.a(1, -1, 1), net.minecraft.v1.EAST);
		}else if(pb.a(-1, -1, 1) != null) {
			if(pb.a(-1, -1, 0) != null)
				place(pb.a(0, -1, 1), net.minecraft.v1.WEST);
			place(pb.a(-1, -1, 1), net.minecraft.v1.SOUTH);
		}else if(pb.a(-1, -1, -1) != null) {
			if(pb.a(0, -1, -1) != null)
				place(pb.a(0, -1, 1), net.minecraft.v1.SOUTH);
			place(pb.a(-1, -1, 1), net.minecraft.v1.WEST);
		}else if(pb.a(1, -1, -1) != null) {
			if(pb.a(1, -1, 0) != null)
				place(pb.a(1, -1, 0), net.minecraft.v1.EAST);
			place(pb.a(1, -1, -1), net.minecraft.v1.NORTH);
		}
		
		
		if(f == net.minecraft.v1.UP)
			p = p.a(0, -1, 0);
		else if(f == net.minecraft.v1.NORTH)
			p = p.a(0, 0, 1);
		else if(f == net.minecraft.v1.EAST)
			p = p.a(-1, 0, 0);
		else if(f == net.minecraft.v1.SOUTH)
			p = p.a(0, 0, -1);
		else if(f == net.minecraft.v1.WEST)	
			p = p.a(1, 0, 0);
			
			
			
			
			
			
			
			
			
			if(getDistanceToEntity(instance().U, ent) <= (15.4515434F)) {
	        	   if (Aimbot.state) {
	        		   faceEntity(ent);
	        	   }
	       // 	   for (Object entity : instance().g.O) {
	       //			if (((net.minecraft.nU) entity).O() && entity != instance().aw) {
	       //				System.out.println("senkimsin ya");
	       //				instance().g.e((net.minecraft.nU) entity);
	       //			}
	      // 		}
	        	   
	    	   //toRotation(getCenter(ent.hell()), true);
	        	   instance().U.cN.a(new net.minecraft.i4(ent, net.minecraft.ia.ATTACK));
	        	   instance().U.cN.a(new net.minecraft.i4(ent, net.minecraft.ia.ATTACK));
	        	   instance().U.K();
		           continue;
	           } else {
	        	   instance().U.cN.a(new net.minecraft.i4(ent, net.minecraft.ia.ATTACK));
	        	   instance().U.cN.a(new net.minecraft.i4(ent, net.minecraft.ia.ATTACK));
	        	   instance().U.K();
		           
	           }
	           if(getDistanceToEntity(instance().U, ent) <= (6.2713613F)) {
	        	   if (Aimbot.state) {
	        		   faceEntity(ent);
	        	   }
	      //  	   for (Object entity : instance().g.O) {
	       //			if (((net.minecraft.nU) entity).O() && entity != instance().aw) {
	       //				System.out.println("senkimsin ya");
	      // 				instance().g.e((net.minecraft.nU) entity);
	      // 			}
	      // 		}
	    	   //toRotation(getCenter(ent.hell()), true);
	        	   instance().U.cN.a(new net.minecraft.i4(ent, net.minecraft.ia.ATTACK));
	        	   
	        	   instance().U.K();
	           continue;
	           }
	 */
		
	
	
	public float as() {
		if (Reach.state) {
			return 10f;
		}
	    
		return 4.5f;
	}
	
public static void onMotionUpdate() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InterruptedException {
	if (FastPlace.state) {
		
		
		Field privateFieldxx = net.minecraft.client.cN.class.getDeclaredField("B");
			privateFieldxx.setAccessible(true);
			privateFieldxx.setInt(instance(), 1);
		//	instance().aw.b0.d = true;
		//	instance().aw.b0.e = true;
	}
	if (FastHit.state) {
		Field privateField = net.minecraft.client.cN.class.getDeclaredField("aq");
		privateField.setAccessible(true);
		privateField.setInt(instance(), 0);
	}
	
	if (InvisibleCleaner.state) {
		
	}
//	if (FastBow.state) {
//		if ((instance().aw.r) && instance().aw.b7.a() != null && instance().aw.b7.a().a() instanceof net.minecraft.g8) {
//			instance().O.a(instance().aw, instance().g, instance().aw.b7.a());
//			instance().aw.b7.a().a().a(instance().aw.b7.a(), instance().g, instance().aw)
			
			
//		}
//	}
//	if (Xray.state) {
//		instance().am.h();
//	}
	if (SpeedMine.state) {
		
		Field filedd = net.minecraft.client.cA.class.getDeclaredField("c");
		filedd.setAccessible(true);
		filedd.setInt(instance().z, 0);
		Field filedd1 = net.minecraft.client.cA.class.getDeclaredField("i");
		filedd1.setAccessible(true);
		filedd1.setFloat(instance().z, 1.0F);
		
		
	} else {
		//instance().aw.k(net.minecraft.ln.a.c());
	}
//	if (Nuker.state) {
//		for(int x = -radius; x < radius; x++) {
//			for(int y = radius; y > -radius; y++) {
//				for(int z = -radius; z < radius; z++) {
//					xPos = (int)instance().aw.m + x;
//					yPos = (int)instance().aw.X + y;
//					zPos = (int)instance().aw.n + z;
//					
//					net.minecraft.BlockPos blockPos1 = new net.minecraft.BlockPos(xPos, yPos, zPos);
//					
//					instance().aw.cI.a(new net.minecraft.qC(net.minecraft.uN.START_DESTROY_BLOCK, blockPos1, net.minecraft.l0.NORTH));
//					instance().aw.cI.a(new net.minecraft.qC(net.minecraft.uN.STOP_DESTROY_BLOCK, blockPos1, net.minecraft.l0.NORTH));
//					
//				}
//			}
//		}
//	}
	
	
	if (Fly.state) {
		if (Fly.starty > instance().f.a) {
			instance().f.a(0.2D);
			instance().f.R();
		    
		}
		
		
		
		
		//instance().aV.b4.f = true;
		//instance().aV.b4.e.a(true);
		//instance().aV.b4.h.a(true);
		//instance().aw.b0.e = true;
	//	instance().aV.W = 0.0f;
	//	instance().aV.u = true;
		
	//	instance().aw.b0.a(0.05F);
		//timerr.timerSpeed = 0.09F;
		
	//	Field privateField3 = net.minecraft.client.dR.class.getDeclaredField("E");
	//	privateField3.setAccessible(true);
	    
	  //  Object sa = (instance());
		//privateField3.setFloat(instance().aw, 0.901F);
	//	Field privateField = net.minecraft.o6.class.getDeclaredField("bY");
	//	privateField.setAccessible(true);
	//	privateField.setFloat(instance().aw, 0.0100F);
	//	Field privateFieldx = net.minecraft.o6.class.getDeclaredField("cd");
	//	privateFieldx.setAccessible(true);
	//	privateFieldx.setFloat(instance().aw, 0.02035F);
	//	Field privateFieldxx = net.minecraft.bZ.class.getField("").getClass().getField("i");
	//	System.out.println("ananqweqweq");
		//privateFieldxx.setAccessible(true);
	//	privateFieldxx.setFloat(instance().getClass().getField("E"), 0.9F);
		
	//	Field ananoc = instance().getClass().getDeclaredField("E");
	//	Object bos = instance();
	//	Object bos1 = bos.getClass().getDeclaredField("E");
	//	ananoc.setAccessible(true);
	//	Field bosyapion = bos1.getClass().getField("i");
	//	bosyapion.setFloat(bos1, 0.9F);
		
		
	
	//	b.i = 0.09F;
		//if (instance().ah.I <= -0.8f) {
		//	instance().ah.I = 0.0f;
		//	instance().ah.J = true;
		//}
	} else {
		
	}
	if (Aimbot.state) {
		for(int a = 0; a < instance().aQ.H.size(); ++a) {
		       if (instance().aQ.H.size() <= a) {
		          a = 0;
		       }
	       
		       net.minecraft.oN ent = (net.minecraft.oN)instance().aQ.H.get(a);
		       if ((ent != null && ent != instance().f && Aimbot.state)) {
		           if(getDistanceToEntity(instance().f, ent) <= (4.50F)) {
		        	   if (Aimbot.state) {
		        		   faceEntity(ent);
		        	   }   
			           
	           }
	           }
	       }
	}
	if (FullBright.state) {
		Field fileddd = net.minecraft.client.er.class.getDeclaredField("bJ");
		fileddd.setAccessible(true);
		fileddd.setFloat(instance().ar, 100);
	}
	if (AutoArmor.state) {
		boots = new int[] { 313, 309, 317, 305, 301 };
		chestplate = new int[] { 311, 307, 315, 303, 299 };
		helmet = new int[] { 310, 306, 314, 302, 298 };
		leggings = new int[] { 312, 308, 316, 304, 300 };

		delay = 0;
		if (instance().A instanceof net.minecraft.client.g6 && !(instance().A instanceof net.minecraft.client.gZ)) {
			anan12 = false;
		} else {
			anan12 = true;
		}
		
	//	if (instance().e instanceof net.minecraft.client.b3 && !(instance().e instanceof net.minecraft.client.c6)) {
	//		return;
	//	}
		if (anan12) {
			if (delay <= 0) {
				
				for (int i = 5; i < 9; i++) {
					 net.minecraft.d8 stack = instance().f.cj.a(i).a();
					int value = getProt(stack);
					int type = i - 5;
					int bestSlot = -1;
					int highestValue = 0;
					for (int inv = 9; inv < 45; inv++) {
						
						
						final net.minecraft.d8 invStx = instance().f.cj.a(inv).a();
						if ((invStx != null) && ((invStx.a() instanceof net.minecraft.qc))) {
							net.minecraft.qc armour = (net.minecraft.qc) invStx.a();
							int armourProtection = armour.n
									+ net.minecraft.az.a(net.minecraft.iq.e.v, invStx);
							if ((armour.o  == type) && (armourProtection > value)
									&& (armourProtection > highestValue)) {
								highestValue = armourProtection;
								bestSlot = inv;
							}
						}
					}
					if (bestSlot != -1) {
						if (stack == null) {
							instance().z.a(0, bestSlot, 0, 1, instance().f);
						} else {
							instance().z.a(0, i, 1, 4, instance().f);
							instance().z.a(0, bestSlot, 0, 1, instance().f);
						}
						return;
					}
					delay = 12;
				}
			} else {
				--delay;
			}
		}
		
	}
//	if (Phase.state) {
//		if (instance().ah.J) {
//			double[] vals = { 0.333, 0 };
//			for (double i : vals) {
//			instance().ah.cF.a(new net.minecraft.it(
//					instance().ah.at, instance().ah.Y + i, instance().ah.O, false, 1F));
//		}
//		}
//	}
	if (NoKnockback.state)  {
		
		if (instance().f.aQ == 9) {
			motionX = instance().f.Z;
			motionZ = instance().f.q;
		} else if (instance().f.aQ == 8) {
			instance().f.Z = motionX * 0.00000000000000000000000000000000001D;
			instance().f.q = motionZ * 0.00000000000000000000000000000000001D;
		}
	}
//	if (AntiBan.state) {
//		
//		for (Object entity : instance().N.p) {
//			if (((net.minecraft.qo) entity).y() && entity != instance().aw) {
//				System.out.println("senkimsin ya");
//				instance().g.e((net.minecraft.nU) entity);
//			}
//		}
//	}
	if (ESP.state) {
		GL11.glEnable(32823);
        GL11.glPolygonOffset(1.0f, -1100000.0f);
	}
	//if (SafeWalk.state && instance().ah !=null && instance().ad != null) {
	//	final double posX = instance().ah.at;
	//	final double y = instance().ah.Y - 1.0;
	//	final net.minecraft.BlockPos BP = new net.minecraft.BlockPos(posX, y, instance().ah.O);
	//	if (instance().ad.a(BP) == Blocks.air) {
    //        instance().ae.bI.b = true;
    //    }
    //    else {
   //         SafeWalk.mc.gameSettings.keyBindSneak.pressed = false;
    //    }
//	}
	
	
//	double oldY = instance().ah.l;
//	float oldJ = instance().ah.br;
//	if (Glide.state && (instance().ah.l < 0.0d) && (instance().ah.R)&& (!instance().ah.v()) && (!instance().ah.af())) {
//		System.out.println("kontroller calisiyo");
//		if (!instance().ah.a(net.minecraft.g9.J)) {
//			System.out.println("lava calisiyo");
//			instance().ah.l = -.125d;
//			instance().ah.br *= 1.12337f;
//		}
//	}
	if (VanillaFly.state) {
		instance().f.bJ.c.a(true);
		instance().f.bJ.a.a(true);
	} else {
		instance().f.bJ.c.a(false);
		instance().f.bJ.a.a(false);
	}
	//if (Velocity.state && )
	if (NoFall.state && instance().f.ag > 2) {
		System.out.println("mutesekkirim");
		instance().f.cG.a(new net.minecraft.sU(true));
	}
//	if(Deneme.state) {
//		start();
//	}
	
	if(Step.state){
		instance().f.O = 1.0F;
	} else {instance().f.O = 0.5F;
	}
	TimeHelper bos = new TimeHelper();
	if(ChestStealer.state) {
		System.out.println("chest calisiyo");
		if((instance().f.bN != null) && (instance().f.bN instanceof net.minecraft.u2)){
			System.out.println("chest calisiyomu");
			net.minecraft.u2 chest = (net.minecraft.u2) instance().f.bN;
			for(int i = 0; i < chest.a().d(); i++) {
				System.out.println("chest topluy1o");
			if((chest.a().a(i) != null) && bos.hasReached(700L)){
				
				instance().z.a(chest.i, i, 0 ,1, instance().f);
				System.out.println("chest topluyo");
			    bos.reset();
			}
			}
	}}
	
	//if(Scaffold.state) {
	
		
	//net.minecraft.BlockPos pos = instance().ah.ck.a(instance().ah.at, instance().ah.Y - 1.0D, instance().ah.O);
	//if(instance().a(). instanceof net.minecraft.dy) {
		
	//}
	//}
if(Speed.state) {
    if(!isMoving())
        return;
	strafe(getSpeed() * 1.10F);
}

if (Aura.state && instance().f != null && instance().aQ != null && instance().aQ.H != null && !instance().aQ.H.isEmpty()) {
	
	for(int a = 0; a < instance().aQ.H.size(); ++a) {
	       if (instance().aQ.H.size() <= a) {
	          a = 0;
	       }
	       net.minecraft.oN ent = (net.minecraft.oN)instance().aQ.H.get(a);
	       if ((ent != null && ent != instance().f && Aura.state)) {
	    	   instance().f.cG.a(new net.minecraft.K(ent, net.minecraft.lU.ATTACK));
	    	   instance().f.B();
	           
	           }
	       }
	      }
	
if (LegitKillAura.state && instance().f != null && instance().aQ != null && instance().aQ.H != null && !instance().aQ.H.isEmpty()) {
	
	for(int a = 0; a < instance().aQ.H.size(); ++a) {
	       if (instance().aQ.H.size() <= a) {
	          a = 0;
	       }
	       net.minecraft.oN ent = (net.minecraft.oN)instance().aQ.H.get(a);
	       instance().f.cG.a(new net.minecraft.K(ent, net.minecraft.lU.ATTACK));
	       if ((ent != null && ent != instance().f && LegitKillAura.state)) {
	           if(getDistanceToEntity(instance().f, ent) <= (4.50F)) {
	        	   if (Aimbot.state) {
	        		   faceEntity(ent);
	        	   }
	        //	   for (Object entity : instance().g.O) {
	       	//		if (((net.minecraft.nU) entity).O() && entity != instance().aw) {
	       	//			System.out.println("senkimsin ya");
	       	//			instance().g.e((net.minecraft.nU) entity);
	       	//		}
	       	//	}
    	   //toRotation(getCenter(ent.hell()), true);
	        	   instance().f.cG.a(new net.minecraft.K(ent, net.minecraft.lU.ATTACK));
		    	   instance().f.B();
		           
           }
           }
       }
      }
    }

    


public static boolean isMoving() {
    return instance().f != null && (instance().f.cz.a != 0F || instance().f.cz.c != 0F);
}

public static void scale(double p_179139_0_, double p_179139_2_, double p_179139_4_)
{
    GL11.glScaled(p_179139_0_, p_179139_2_, p_179139_4_);
}
public static long randomDelay(final int minDelay, final int maxDelay) {
    return nextInt(minDelay, maxDelay);
}
public static int nextInt(final int startInclusive, final int endExclusive) {
    if (endExclusive - startInclusive <= 0)
        return startInclusive;

    return startInclusive + new Random().nextInt(endExclusive - startInclusive);
}
public static void get() {
    GL11.glPopMatrix();
}
public static void pushMatrix() {
    GL11.glPushMatrix();
}
public static void onRender2D(int SRwidth, int SRheight) throws NoSuchAlgorithmException, IOException, URISyntaxException {
	   if(!lol) {
		   try {
			   HttpsURLConnection connection = (HttpsURLConnection)(new URL("https://raw.githubusercontent.com/noksyXD/kolaymad/master/hwidforsoi")).openConnection();
	           connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
	           BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	           StringBuilder response = new StringBuilder();

	           String currentln;
	           while((currentln = in.readLine()) != null) {
	               response.append(currentln);
	           }
	           if (!response.toString().contains(dump())) {
	        	   System.exit(0);
	           } else {
	        	   moduleManager = new ModuleManager();
	           }
		   } catch(IOException e) {
			   System.exit(0);
		   }
		   try {
			   HttpsURLConnection connection1 = (HttpsURLConnection)(new URL("https://raw.githubusercontent.com/noksyXD/kolaymad/master/loginsoi")).openConnection();
	           connection1.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
	           BufferedReader in1 = new BufferedReader(new InputStreamReader(connection1.getInputStream()));
	           StringBuilder response1 = new StringBuilder();

	           String currentln1;
	           while((currentln1 = in1.readLine()) != null) {
	               response1.append(currentln1);
	           }
	           if (!response1.toString().contains("true")) {
	               System.out.println("SOI servers closed. Please download new version or try again later");
	               System.exit(0);
	           } else {
	        	   
	           }
		   } catch (IOException var22) {
			   System.exit(0);
		   }
		      
		      
		      System.out.println("[" + new SimpleDateFormat("HH:mm:ss").format(System.currentTimeMillis()) + "] " + "[Client thread/INFO]: SOI Client yuklendi.");
		   lol = true;
	   }
	   net.minecraft.client.cG sr3 = new net.minecraft.client.cG(instance());
	   net.minecraft.client.cG sr1 = new net.minecraft.client.cG(instance());
	   net.minecraft.client.dN fn1 = instance().aC;
	   int color1 = 159;
	   int color2 = 181;
	   int color3 = 181;
	   
	  // instance().ap.b("LegitKillAura [Y]", 2, 20, (new Color(color1,color2, color3).getRGB()), true);
	  // instance().ap.b("Aimbot [H]", 2, 30, (new Color(color1,color2, color3).getRGB()), true);
	 //  instance().ap.b("KillAura [R]", 2, 40, (new Color(color1,color2, color3).getRGB()), true);
	 //  instance().ap.b("Strafe [G]", 2, 50, (new Color(color1,color2, color3).getRGB()), true);
	 //  instance().ap.b("Step [F]", 2, 60, (new Color(color1,color2, color3).getRGB()), true);
	 //  instance().ap.b("ChestStealer [V]", 2, 70, (new Color(color1,color2, color3).getRGB()), true);
	 //  instance().ap.b("NoFall [M]", 2, 80, (new Color(color1,color2, color3).getRGB()), true);
	   net.minecraft.client.cG sr = new net.minecraft.client.cG(instance());
	   
	   int rainbowSpeed = (int) (10 + .00001);
	   net.minecraft.client.dN fn = instance().aC;
	   
	   //net.minecraft.client.gl.d();
	  // net.minecraft.client.gl.F(); 
	   //net.minecraft.client.gl.a(1f, 1f, 1f, 1f);
   //String text = "V" + net.minecraft.tb.WHITE + "ega";
   //float width = instance().aD.a(text) + 6;
	   //instance()..b(new net.minecraft.q7(""));
	   //net.minecraft.client.en.a(10, 10, 0, 0, 86, 49, 86, 49);
   //int height = 20;
   //int posX = 2;
   //int posY = 2;
   //int hue = 81;
   //net.minecraft.client.ij.a(posX, posY, (int)((float)posX + width + 2.0F), posY + height, (new Color(5, 5, 5, 255)).getRGB());
   //drawBorderedRect(posX + 1, (int)((double)posY + 0.5D), (int)((double)((float)posX + width) + 1.5D), (int)((double)(posY + height) - 0.5D), 0, (new Color(40, 40, 40, 255)).getRGB(), (new Color(60, 60, 60, 255)).getRGB(), true);
   //drawBorderedRect(posX + 2, posY + 2, (int)((float)posX + width), posY + height - 2, 1, (new Color(22, 22, 22, 255)).getRGB(), (new Color(60, 60, 60, 255)).getRGB(), true);
   //net.minecraft.client.ij.a((int)((double)posX + 2.5D), (int)((double)posY + 2.5D), (int)((double)((float)posX + width) - 0.5D), (int)((double)posY + 4.5D), (new Color(9, 9, 9, 255)).getRGB());
   //drawGradientSideways(4, posY + 3, (int)(4.0F + width / 3.0F), posY + 4, (new Color(81, 149, 219, 255)).getRGB(), (new Color(180, 49, 218, 255)).getRGB());
   //drawGradientSideways((int)(4.0F + width / 3.0F), posY + 3, (int)(4.0F + width / 3.0F * 2.0F), posY + 4, (new Color(180, 49, 218, 255)).getRGB(), (new Color(236, 93, 128, 255)).getRGB());
   //drawGradientSideways((int)(4.0F + width / 3.0F * 2.0F), posY + 3, (int)(width / 3.0F * 3.0F) + 1, posY + 4, (new Color(236, 93, 128, 255)).getRGB(), (new Color(167, 171, 90, 255)).getRGB());
  //instance().aD.a(text + " " + net.minecraft.tb.GRAY + "b2", 2, 2, new Color(255, 135, 0).getRGB(), true);
   //GL11.glPushMatrix(); //Start new matrix
   //GL11.glScalef(1.8F, 1.8F, 1.8F); //scale it to 0.5 size on each side. Must be float e.g.: 2.0F
   //instance().aD.a(text, 6, 10, new Color(255,0,0).getRGB(), true);
   //GL11.glPopMatrix(); //End this matrix
   //GL11.glPushMatrix(); //Start new matrix
   //GL11.glScalef(0.9F, 0.9F, 0.9F); //scale it to 0.5 size on each side. Must be float e.g.: 2.0F
   //instance().aD.a(cum, 108, 18, new Color(255,255,255).getRGB(), true);
   //GL11.glPopMatrix(); //End this matrix
  //instance().aD.a("Ground:" + " " + (instance().G.W ? net.minecraft.tb.GREEN : net.minecraft.tb.RED) + (instance().G.W ? "true" : "false"), 2, 10, new Color(255, 135, 0).getRGB());
   int y = 24;
   int count = 0;
   Iterator var9 = ModuleManager.getModules().iterator();
   
   if (!Hud.state) {
	 //  Module mod = (Module)var9.next();
	   pushMatrix();
	   
	   fn.a("FullBright", sr.b() - fn.a("FullBright") -2, 4, getRainbow1(4, 0.8f, 1, count * 100));
	   fn.a("AntiBan", sr.b() - fn.a("AntiBan") -2, 14, getRainbow1(4, 0.8f, 1, count * 100));
	 //  fn.a("SOI 1.4", 4, 4, getRainbow1(2, 0.5f, 2, count * 500));
	   instance().aC.b("SOI 1.5", 2, 2, getRainbow1(2, 0.5f, 2, count * 500), true);
	   
	   get();
	   
	   net.minecraft.client.f6.a(75, 20, 2, 40, TabManager.getCurrentTab()==0 ? 0xff0090ff : 0x90000000);
	   fn.a("Combat", 5, 26, 0xffffff);
		
	   net.minecraft.client.f6.a(75, 40, 2, 60, TabManager.getCurrentTab()==1 ? 0xff0090ff : 0x90000000);
		fn.a("Player", 5, 46, 0xffffff);
		
		
		if(TabManager.getTabs().get(0).isExpanded()){
			net.minecraft.client.f6.a(150, 20, 77, 40, TabManager.getCurrentRenderMod() == 0 ? 0xff0090ff:0x90000000);
			fn.a("Aura", 81, 26, 0xffffff);
			net.minecraft.client.f6.a(150, 40, 77, 60, TabManager.getCurrentRenderMod() == 1 ? 0xff0090ff:0x90000000);
			fn.a("LegitKillAura", 81, 46, 0xffffff);
			net.minecraft.client.f6.a(150, 60, 77, 80, TabManager.getCurrentRenderMod() == 2 ? 0xff0090ff:0x90000000);
			fn.a("Aimbot", 81, 66, 0xffffff);
			net.minecraft.client.f6.a(150, 80, 77, 100, TabManager.getCurrentRenderMod() == 3 ? 0xff0090ff:0x90000000);
			fn.a("FastHit", 81, 86, 0xffffff);
			net.minecraft.client.f6.a(150, 100, 77, 120, TabManager.getCurrentRenderMod() == 4 ? 0xff0090ff:0x90000000);
			fn.a("Reach", 81, 106, 0xffffff);
			
		}
		
		if(TabManager.getTabs().get(1).isExpanded()){
			net.minecraft.client.f6.a(150, 40, 77, 60, TabManager.getCurrentMovementMod() == 0 ? 0xff0090ff:0x90000000);
			fn.a("Fly", 81,  46,  0xffffff);
			net.minecraft.client.f6.a(150, 60, 77, 80, TabManager.getCurrentMovementMod() == 1 ? 0xff0090ff:0x90000000);
			fn.a("AutoArmor", 81,  66,  0xffffff);
			net.minecraft.client.f6.a(150, 80, 77, 100, TabManager.getCurrentMovementMod() == 2 ? 0xff0090ff:0x90000000);
			fn.a("ChestStealer", 81,  86,  0xffffff);
			net.minecraft.client.f6.a(150, 100, 77, 120, TabManager.getCurrentMovementMod() == 3 ? 0xff0090ff:0x90000000);
			fn.a("FastPlace", 81,  106,  0xffffff);
			net.minecraft.client.f6.a(150, 120, 77, 140, TabManager.getCurrentMovementMod() == 4 ? 0xff0090ff:0x90000000);
			fn.a("NoFall", 81,  126,  0xffffff);
			net.minecraft.client.f6.a(150, 140, 77, 160, TabManager.getCurrentMovementMod() == 5 ? 0xff0090ff:0x90000000);
			fn.a("NoKnockback", 81,  146,  0xffffff);
			net.minecraft.client.f6.a(150, 160, 77, 180, TabManager.getCurrentMovementMod() == 6 ? 0xff0090ff:0x90000000);
			fn.a("Speed", 81,  166,  0xffffff);
			net.minecraft.client.f6.a(150, 180, 77, 200, TabManager.getCurrentMovementMod() == 7 ? 0xff0090ff:0x90000000);
			fn.a("SpeedMine", 81,  186,  0xffffff);
			net.minecraft.client.f6.a(150, 200, 77, 220, TabManager.getCurrentMovementMod() == 8 ? 0xff0090ff:0x90000000);
			fn.a("InvisibleCleaner", 81,  206,  0xffffff);
			net.minecraft.client.f6.a(150, 220, 77, 240, TabManager.getCurrentMovementMod() == 9 ? 0xff0090ff:0x90000000);
			fn.a("VanillaFly", 81,  226,  0xffffff);
			
			
		}
		
	      
	   
	   
   
   
   
 //  instance().ah.a(new net.minecraft.qW(NoFall.state ? Module.getModuleName() + "enabled" : "disabled"));
   while(var9.hasNext()) {
      Module mod = (Module)var9.next();
      
         if(mod.moduleState) {
        	 if (!Hud.state) {
        		 int offset = count*(9 + 2);
        	        //	 instance().ah.a(new net.minecraft.qW("sa oc"));
        	 			//Gui.drawRect(sr.getScaledWidth() - fr.getStringWidth(m.name) - 8, offset, sr.getScaledWidth(), 6 + fr.FONT_HEIGHT + offset -4, new Color(20,20,20, 120).getRGB());
        	        //	 net.minecraft.client.b_.a(sr.b() - fn.a(mod.moduleName) -2, y, arg2, arg3, arg4);
        	        	 fn.a(mod.moduleName, sr.b() - fn.a(mod.moduleName) -2, y, getRainbow1(4, 0.8f, 1, count * 100));
        	        	 
        	        	 //net.minecraft.client.b_.a((sr.b() - instance().ap.a(mod.moduleName) + 8) - 4, 4, 1, offset);
        	        	 //instance().ap.b(mod.moduleName, 2, y, (new Color(57,224, 58).getRGB()), true);
        	         y += 10;
        	         count++;
        	 }
         }
   
         }
         
   }
//   boolean foundModule1 = true;
//   boolean foundModule = false;
//   for (Module mod1 : ModuleManager.getModules()) {
//	   if (!foundModule &&mod1.moduleState)  {
//		   sendchat(mod1.moduleName + (mod1.getModuleState() ? "enabled" : "disabled"));
//		   foundModule = true;
//		   foundModule1 = false;
//		   break;
//	   }
//   }
   
//   for (Module mod1 : ModuleManager.getModules()) {
//	   if (!foundModule1 &&mod1.moduleState)  {
//		   sendchat(mod1.moduleName + (mod1.moduleState ? " enabled" : " disabled"));
//		   foundModule1 = true;
//		   
//		   break;
//	   }
 //  }
   
   if (NoFall.statechat && !statenofall1) {
	  if (NoFall.state) {
		  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5NoFall �7has �aenabled"));
	  }
  	 
  	 NoFall.statechat = !NoFall.statechat;
  	// statenofall1 = true;
  	 statenofall = true;
  	 
  	 
   }
   if (!NoFall.state && statenofall) {
	   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5NoFall �7has �cdisabled"));
  	 statenofall = false;
  	 statenofall1 = false;
   }
   if (Aura.statechat && !statekillaura1) {
		  if (Aura.state) {
			  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5KillAura �7has �aenabled"));
		  }
	  	 
	  	 Aura.statechat = !Aura.statechat;
	  	// statenofall1 = true;
	  	 statekillaura = true;
	  	 
	  	 
	   }
	   if (!Aura.state && statekillaura) {
		   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5KillAura �7has �cdisabled"));
	  	 statekillaura = false;
	  	 statekillaura1 = false;
	   }
	   if (Aimbot.statechat && !statenaimbot1) {
			  if (Aimbot.state) {
				  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Aimbot �7has �aenabled"));
			  }
		  	 
		  	 Aimbot.statechat = !Aimbot.statechat;
		  	// statenofall1 = true;
		  	 stateaimbot = true;
		  	 
		  	 
		   }
		   if (!Aimbot.state && stateaimbot) {
			   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Aimbot �7has �cdisabled"));
		  	 stateaimbot = false;
		  	 statenaimbot1 = false;
		   }
		   if (AutoArmor.statechat && !stateautoarmor1) {
				  if (AutoArmor.state) {
					  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5AutoArmor �7has �aenabled"));
				  }
			  	 
				  AutoArmor.statechat = !AutoArmor.statechat;
			  	// statenofall1 = true;
			  	 stateautoarmor = true;
			  	 
			  	 
			   }
			   if (!AutoArmor.state && stateautoarmor) {
				   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5AutoArmor �7has �cdisabled"));
			  	 stateautoarmor = false;
			  	 stateautoarmor = false;
			   }
			   if (ChestStealer.statechat && !statecheststealer1) {
					  if (ChestStealer.state) {
						  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5ChestStealer �7has �aenabled"));
					  }
				  	 
					  ChestStealer.statechat = !ChestStealer.statechat;
				  	// statenofall1 = true;
				  	 statecheststealer = true;
				  	 
				  	 
				   }
				   if (!ChestStealer.state && statecheststealer) {
					   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5ChestStealer �7has �cdisabled"));
				  	statecheststealer = false;
				  	statecheststealer1 = false;
				   }
				   if (LegitKillAura.statechat && !statelegitkillaura1) {
						  if (LegitKillAura.state) {
							  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5LegitKillAura �7has �aenabled"));
						  }
					  	 
						  LegitKillAura.statechat = !LegitKillAura.statechat;
					  	// statenofall1 = true;
						  statelegitkillaura = true;
					  	 
					  	 
					   }
					   if (!LegitKillAura.state && statelegitkillaura) {
						   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5LegitKillAura �7has �cdisabled"));
					  	statelegitkillaura = false;
					  	statelegitkillaura1 = false;
					   }
					   if (NoKnockback.statechat && !statenoknockback1) {
							  if (NoKnockback.state) {
								  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5NoKnockback �7has �aenabled"));
							  }
						  	 
							  NoKnockback.statechat = !NoKnockback.statechat;
						  	// statenofall1 = true;
							  statenoknockback = true;
						  	 
						  	 
						   }
						   if (!NoKnockback.state && statenoknockback) {
							   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5NoKnockback �7has �cdisabled"));
						  	statenoknockback = false;
						  	statenoknockback1 = false;
						   }
						   if (Speed.statechat && !statespeed1) {
								  if (Speed.state) {
									  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Speed �7has �aenabled"));
								  }
							  	 
								  Speed.statechat = !Speed.statechat;
							  	// statenofall1 = true;
								  statespeed = true;
							  	 
							  	 
							   }
							   if (!Speed.state && statespeed) {
								   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Speed �7has �cdisabled"));
							  	statespeed = false;
							  	statespeed1 = false;
							   }
							   if (Step.statechat && !statestep1) {
									  if (Step.state) {
										  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Step �7has �aenabled"));
									  }
								  	 
									  Step.statechat = !Step.statechat;
								  	// statenofall1 = true;
									  statestep = true;
								  	 
								  	 
								   }
								   if (!Step.state && statestep) {
									   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Step �7has �cdisabled"));
								  	statestep = false;
								  	statestep1 = false;
								   }
								   if (SpeedMine.statechat && !statespeedmine1) {
										  if (SpeedMine.state) {
											  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5SpeedMine �7has �aenabled"));
										  }
									  	 
										  SpeedMine.statechat = !SpeedMine.statechat;
									  	// statenofall1 = true;
										  statespeedmine = true;
									  	 
									  	 
									   }
									   if (!SpeedMine.state && statespeedmine) {
										   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5SpeedMine �7has �cdisabled"));
										   statespeedmine = false;
										   statespeedmine1 = false;
									   }
									   if (Fly.statechat && !statefly1) {
											  if (Fly.state) {
												  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Fly �7has �aenabled"));
											  }
										  	 
											  Fly.statechat = !Fly.statechat;
										  	// statenofall1 = true;
											  statefly = true;
										  	 
										  	 
										   }
										   if (!Fly.state && statefly) {
											   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Fly �7has �cdisabled"));
											   statefly = false;
											   statefly1 = false;
										   }
										   if (FastPlace.statechat && !statefastplace1) {
												  if (FastPlace.state) {
													  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5FastPlace �7has �aenabled"));
												  }
											  	 
												  FastPlace.statechat = !FastPlace.statechat;
											  	// statenofall1 = true;
												  statefastplace = true;
											  	 
											  	 
											   }
											   if (!FastPlace.state && statefastplace) {
												   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5FastPlace �7has �cdisabled"));
												   statefastplace = false;
												   statefastplace1 = false;
											   }
											   if (Reach.statechat && !statereach1) {
													  if (Reach.state) {
														  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Reach �7has �aenabled"));
													  }
												  	 
													  Reach.statechat = !Reach.statechat;
												  	// statenofall1 = true;
													  statereach = true;
												  	 
												  	 
												   }
												   if (!Reach.state && statereach) {
													   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Reach �7has �cdisabled"));
													   statereach = false;
													   statereach1 = false;
												   }
												   if (FastHit.statechat && !statefasthit1) {
														  if (FastHit.state) {
															  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5FastHit �7has �aenabled"));
														  }
													  	 
														  FastHit.statechat = !FastHit.statechat;
													  	// statenofall1 = true;
														  statefasthit = true;
													  	 
													  	 
													   }
													   if (!FastHit.state && statefasthit) {
														   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5Fasthit �7has �cdisabled"));
														   statefasthit = false;
														   statefasthit1 = false;
													   }
													   if (InvisibleCleaner.statechat && !stateinvisiblecleaner1) {
															  if (InvisibleCleaner.state) {
																  instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5InvisibleCleaner �7has �aenabled"));
															  }
														  	 
															  InvisibleCleaner.statechat = !InvisibleCleaner.statechat;
														  	// statenofall1 = true;
															  stateinvisiblecleaner = true;
														  	 
														  	 
														   }
														   if (!InvisibleCleaner.state && stateinvisiblecleaner) {
															   instance().f.a(new net.minecraft.mu("�7[�6SOI�7] �5InvisibleCleaner �7has �cdisabled"));
															   stateinvisiblecleaner = false;
															   stateinvisiblecleaner1 = false;
														   }
   
}
//public static void sendchat(String message) {
//	message = "�7[�6SOI�7] " + message;
//	instance().ah.a(new net.minecraft.qW(message));
//}
public static Color rainbow(int index, int speed, float saturation, float brightness, float opacity) {
    int angle = (int) ((System.currentTimeMillis() / speed + index) % 360);
    float hue = angle / 360f;
    int color = Color.HSBtoRGB(hue, saturation, brightness);
    Color obj = new Color(color);
    return new Color(obj.getRed(), obj.getGreen(), obj.getBlue(), Math.max(0, Math.min(255, (int) (opacity * 255))));
}

public static int getRainbow(int speed, int offset) {
    float hue = (System.currentTimeMillis() + offset) % speed;
    hue /= speed;
    return Color.getHSBColor(hue, 0.75f, 1f).getRGB();

}
public static int getRainbow1(float seconds1, float saturation1, float brightness1, long index1) {
	float hue = ((System.currentTimeMillis() + index1) % (int)(seconds1 * 1000)) / (float)(seconds1 * 1000);
	int color = Color.HSBtoRGB(hue, saturation1, brightness1);
	return color;
}
public static Color astolfo(int index, int speed, float saturation, float brightness, float opacity) {
    int angle = (int) ((System.currentTimeMillis() / speed + index) % 360);
    angle = (angle > 180 ? 360 - angle : angle) + 180;
    float hue = angle / 360f;

    int color = Color.HSBtoRGB(brightness, saturation, hue);
    Color obj = new Color(color);
    return new Color(obj.getRed(), obj.getGreen(), obj.getBlue(), Math.max(0, Math.min(255, (int) (opacity * 255))));
}


public static Color getGradientOffset(Color color1, Color color2, double offset) {
   double inverse_percent;
   int redPart;
   if (offset > 1.0D) {
      inverse_percent = offset % 1.0D;
      redPart = (int)offset;
      offset = redPart % 2 == 0 ? inverse_percent : 1.0D - inverse_percent;
   }

   inverse_percent = 1.0D - offset;
   redPart = (int)((double)color1.getRed() * inverse_percent + (double)color2.getRed() * offset);
   int greenPart = (int)((double)color1.getGreen() * inverse_percent + (double)color2.getGreen() * offset);
   int bluePart = (int)((double)color1.getBlue() * inverse_percent + (double)color2.getBlue() * offset);
   return new Color(redPart, greenPart, bluePart);
}
public static String dump() throws NoSuchAlgorithmException {
    
    
    byte[] encodedBytes = Base64.getEncoder().encode((System.getenv("PROCESSOR_IDENTIFIER") + (System.getenv("NUMBER_OF_PROCESSORS"))+ (System.getenv("PROCESSOR_ARCHITECTURE")) + System.getProperty("user.name") + "s").getBytes());
    MessageDigest md = MessageDigest.getInstance("SHA-1");
    md.update(encodedBytes);
    byte[] digest = md.digest();
    String hex = String.format("%064x", new BigInteger(1, digest));
    StringBuilder buf = new StringBuilder();

    for(int i = 0; i < digest.length; ++i) {
        int halfbyte = digest[i] >>> 4 & 15;
        int var9 = 0;

        do {
            if (halfbyte <= 9) {
                buf.append((char)(48 + halfbyte));
            } else {
                buf.append((char)(97 + (halfbyte - 10)));
            }

            halfbyte = digest[i] & 15;
        } while(var9++ < 1);
    }

    byte[] authBytes = buf.toString().getBytes(StandardCharsets.UTF_8);
    String encoded = Base64.getEncoder().encodeToString(authBytes);
    return encoded.toString();
}
}
class MKeyListener extends KeyAdapter {
	 
    @Override
    public void keyPressed(KeyEvent event) {
 
  char ch = event.getKeyChar();
 
  if (ch == 'a' ||ch == 'b'||ch == 'c' ) {
 
System.out.println(event.getKeyChar());
 
  }
 
  
    }
}
