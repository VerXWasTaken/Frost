
import org.lwjgl.input.Keyboard;

public class ESP extends Module {

	public static boolean state = false;
	
	public ESP() {
		super("ESP", Keyboard.KEY_C, Category.RENDER);
	}
	   public static boolean getStat() {
		      return state;
		   }


	@Override
	public void onToggled() {
		state = !state;
	}
}
