
import org.lwjgl.input.Keyboard;

public class Speed extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public Speed() {
		super("Speed", Keyboard.KEY_G, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }


	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
