
import org.lwjgl.input.Keyboard;

public class Step extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	public Step() {
		super("Step", Keyboard.KEY_U, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
