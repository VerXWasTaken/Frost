
import org.lwjgl.input.Keyboard;

public class Aura extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public Aura() {
		super("KillAura", Keyboard.KEY_R, Category.COMBAT);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		      
		   }

	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
