import java.util.ArrayList;
import java.util.HashMap;

import org.lwjgl.input.Keyboard;


public class TabManager {

	private static ArrayList<Tab> tabs;
	private static int currentTab;

	private static HashMap<Integer, Module> renderMods, movementMods, combatMods;
	private static int currentRenderMod;
	private static int currentCombatMod;
	private static int currentMovementMod;

	public TabManager() {
		tabs = new ArrayList();
		currentTab = 0;
		combatMods = new HashMap();
		renderMods = new HashMap();
		movementMods = new HashMap();
		currentCombatMod = 0;
		currentRenderMod = 0; 
		currentMovementMod = 0;
		tabs.add(new TabOne());
		tabs.add(new TabTwo());
		tabs.add(new TabThree());
		
		
		renderMods.put(0, new Aura());
		renderMods.put(1, new LegitKillAura());
		renderMods.put(2, new Aimbot());
		renderMods.put(3, new FastHit());
		renderMods.put(4, new Reach());
		movementMods.put(0, new Fly());
		movementMods.put(1, new AutoArmor());
		movementMods.put(2, new ChestStealer());
		movementMods.put(3, new FastPlace());
		movementMods.put(4, new NoFall());
		movementMods.put(5, new NoKnockback());
		movementMods.put(6, new Speed());
		movementMods.put(7, new SpeedMine());
		movementMods.put(8, new InvisibleCleaner());
		movementMods.put(9, new VanillaFly());
		
		
		
		
	}
	
	public static ArrayList<Tab> getTabs(){
		return tabs;
	}
	public static int getCurrentCombatMod(){
		return currentCombatMod;
	}
	public static int getCurrentMovementMod(){
		return currentMovementMod;
	}
	
	public static int getCurrentRenderMod(){
		return currentRenderMod;
	}
	
	public static int getCurrentTab(){
		return currentTab;
	}

	public static void keyPress(int k) {
		switch (k) {
		case Keyboard.KEY_UP:
			if(tabs.get(currentTab).isExpanded()){
				switch(currentTab){
				case 0:
					if(currentRenderMod != 0){
						currentRenderMod--;
					}
					break;
				case 1:
					if(currentMovementMod != 0){
						currentMovementMod--;
					}
					break;
				case 2:
					if (currentCombatMod != 0) {
						currentCombatMod--;
					}
					break;
				}
			}else{
				if(currentTab != 0){
					currentTab--;
				}
			}
			break;
		case Keyboard.KEY_DOWN:
			if(tabs.get(currentTab).isExpanded()){
				switch(currentTab){
				case 0:
					if(currentRenderMod != renderMods.size()-1){
						currentRenderMod++;
					}
					break;
				case 1:
					if(currentMovementMod != movementMods.size()-1){
						currentMovementMod++;
					}
					break;
				case 2:
					if (currentCombatMod != combatMods.size()-1) {
						currentCombatMod++;
					}
					break;
				}
			}else{
				if(currentTab != 1){
					currentTab++;
				}
			}
			break;
		case Keyboard.KEY_RIGHT:
			if(tabs.get(currentTab).isExpanded()){
				switch(currentTab){
				case 0:
					toggleMod(renderMods.get(currentRenderMod).getModuleName());
					break;
				case 1:
					toggleMod(movementMods.get(currentMovementMod).getModuleName());
					break;
				case 2:
					toggleMod(combatMods.get(currentCombatMod).getModuleName());
					break;
				}
			}else{
				tabs.get(currentTab).setExpanded(true);
			}
			break;
		case Keyboard.KEY_LEFT:
			if(tabs.get(currentTab).isExpanded()){
				tabs.get(currentTab).setExpanded(false);
			}
			break;
		}
	}
	
	private static void toggleMod(String n){
		for(Module m: ModuleManager.getModules()){
			if(m.getModuleName().equalsIgnoreCase(n)){
				m.toggle();
				break;
			}
		}
	}

}
