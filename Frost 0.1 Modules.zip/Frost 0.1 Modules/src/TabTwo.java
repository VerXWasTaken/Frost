
public class TabTwo extends Tab{

}
