
import org.lwjgl.input.Keyboard;



public class VanillaFly extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public VanillaFly() {
		super("VanillaFly", Keyboard.KEY_H, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}