import java.util.Iterator;

import org.lwjgl.input.Keyboard;

public class NoFall extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public NoFall() {
		super("NoFall", Keyboard.KEY_M, Category.PLAYER);
	}
	
	   public static boolean getStat() {
		   
		      return state;
		      
		   }
	   public static boolean getStat1() {
		      return statechat;
		      
		   }


	@Override
	public void onToggled() {
		
		state = !state;
		statechat = !statechat;
	}
}