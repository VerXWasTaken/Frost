
import org.lwjgl.input.Keyboard;

public class LegitKillAura extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public LegitKillAura() {
		super("LegitKillAura", Keyboard.KEY_Y, Category.COMBAT);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}
