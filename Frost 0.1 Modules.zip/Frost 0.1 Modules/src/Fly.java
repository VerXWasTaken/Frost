
import org.lwjgl.input.Keyboard;

public class Fly extends Module {
	static double starty = 0;

	public static boolean state = false;
	public static boolean statechat = false;
	
	public Fly() {
		super("Fly", Keyboard.KEY_F, Category.MOVEMENT);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
		starty = SOI.instance().i.a;
	}
}
