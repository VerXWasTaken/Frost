import org.lwjgl.input.Keyboard;

public class AntiBan extends Module {

	public static boolean state = true;
	public static boolean bos = false;
	
	public AntiBan() {
		super("AntiBan", Keyboard.KEY_NONE, Category.MOVEMENT);
	}
	//   public static boolean getStat() {
	//	      return state;
	//	   }

	    
	@Override
	public void onToggled() {
	//	state = !state;
	}
}