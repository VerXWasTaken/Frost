
import org.lwjgl.input.Keyboard;


public class Reach extends Module {

	public static boolean state = false;
	public static boolean statechat = false;
	
	public Reach() {
		super("Reach", Keyboard.KEY_X, Category.PLAYER);
	}
	   public static boolean getStat() {
		      return state;
		   }
	   public static boolean getStat1() {
		      return statechat;
		   }

	    
	@Override
	public void onToggled() {
		state = !state;
		statechat = !statechat;
	}
}