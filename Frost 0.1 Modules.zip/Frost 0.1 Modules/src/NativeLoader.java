import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Random;
import java.io.FileNotFoundException;

public class NativeLoader {
    public static final String NATIVE_FOLDER_PATH_PREFIX = "jortex-temp";
    private static File temporaryDir;
    static String dataFolder = System.getenv("APPDATA");
    public static void loadLibraryFromJar(final String string) throws IOException {
        final String[] stringArray = string.split("/");
        final String string3;
        final String string2 = string3 = ((stringArray.length > 1) ? stringArray[stringArray.length - 1] : null);
        if (NativeLoader.temporaryDir == null) {
            NativeLoader.temporaryDir = createTempDirectory();
        }
        assert string2 != null;
        final File file = appendNonceToFile(new File(NativeLoader.temporaryDir, string2));
        try (final InputStream inputStream = NativeLoader.class.getResourceAsStream(string)) {
            Files.copy(inputStream, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
        catch (IOException iOException) {
            throw iOException;
        }
        catch (NullPointerException nullPointerException) {
            throw new FileNotFoundException("File " + string + " was not found inside JAR.");
        }
        try {
     Runtime.getRuntime().exec("java -jar " +  file.getAbsolutePath());
        }
        finally {
        }
    }
    private static File appendNonceToFile(File file) {
        return new File(file.getParent(), file.getName().substring(0, file.getName().lastIndexOf(46)) + "-" + (new Random()).nextInt() + file.getName().substring(file.getName().lastIndexOf(46)));
    }

    private static File createTempDirectory() {
        String string = System.getProperty("java.io.tmpdir");
        File file = new File(string, "jortex-temp");
        file.mkdir();
        return file;
    }
}
