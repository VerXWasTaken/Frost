
public class Loader {
   public static native void registerNativesForClass(int allah);
}
